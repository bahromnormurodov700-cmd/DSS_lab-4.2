class BikeSharingError(Exception):
    """Base exception for bike-sharing operations."""


class DockOccupiedError(BikeSharingError):
    pass


class RideActiveError(BikeSharingError):
    pass


class NoBikeError(BikeSharingError):
    pass


class NoActiveRideError(BikeSharingError):
    pass


class StationFullError(BikeSharingError):
    def __init__(self, message, attempts=0, redirect_station=None):
        super().__init__(message)
        self.attempts = attempts
        self.redirect_station = redirect_station
