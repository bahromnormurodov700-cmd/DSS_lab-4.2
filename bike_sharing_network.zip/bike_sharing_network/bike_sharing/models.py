from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Iterable

from .exceptions import (
    DockOccupiedError, RideActiveError, NoBikeError,
    NoActiveRideError, StationFullError,
)


class BikeStatus(Enum):
    AVAILABLE = "AVAILABLE"
    IN_USE = "IN_USE"
    REPAIR = "REPAIR"


class Bike:
    def __init__(self, bike_id: str):
        self._bike_id = bike_id
        self._status = BikeStatus.IN_USE
        self._dock: Dock | None = None

    @property
    def bike_id(self) -> str:
        return self._bike_id

    @property
    def status(self) -> BikeStatus:
        return self._status

    @property
    def dock(self) -> Dock | None:
        return self._dock

    def send_to_repair(self) -> None:
        if self._dock is None or self._status is not BikeStatus.AVAILABLE:
            raise ValueError("Only a docked available bike can be sent to repair.")
        self._status = BikeStatus.REPAIR

    def finish_repair(self) -> None:
        if self._dock is None or self._status is not BikeStatus.REPAIR:
            raise ValueError("Bike is not waiting for repair in a dock.")
        self._status = BikeStatus.AVAILABLE

    def __repr__(self) -> str:
        return f"Bike(id={self._bike_id!r}, status={self._status.value})"


class Dock:
    def __init__(self, dock_id: str):
        self._dock_id = dock_id
        self._bike: Bike | None = None

    @property
    def dock_id(self) -> str:
        return self._dock_id

    @property
    def bike(self) -> Bike | None:
        return self._bike

    @property
    def is_free(self) -> bool:
        return self._bike is None

    def _park(self, bike: Bike) -> None:
        if not self.is_free:
            raise DockOccupiedError(f"Dock {self._dock_id} is occupied.")
        if bike.dock is not None:
            raise ValueError("Bike is already parked in another dock.")
        self._bike = bike
        bike._dock = self
        bike._status = BikeStatus.AVAILABLE

    def _remove(self) -> Bike:
        if self._bike is None:
            raise NoBikeError(f"Dock {self._dock_id} is empty.")
        bike = self._bike
        self._bike = None
        bike._dock = None
        bike._status = BikeStatus.IN_USE
        return bike

    def __repr__(self) -> str:
        return f"Dock(id={self._dock_id!r}, free={self.is_free})"


class Station:
    def __init__(self, name: str, dock_count: int):
        if dock_count <= 0:
            raise ValueError("A station must have at least one dock.")
        self._name = name
        self._docks = tuple(Dock(f"{name}-{number}") for number in range(1, dock_count + 1))

    @property
    def name(self) -> str:
        return self._name

    @property
    def docks(self) -> tuple[Dock, ...]:
        return self._docks

    @property
    def free_docks(self) -> int:
        return sum(dock.is_free for dock in self._docks)

    @property
    def docked_bikes(self) -> int:
        return len(self) 

    def __len__(self) -> int:
        return sum(dock.bike is not None for dock in self._docks)

    def park_bike(self, bike: Bike) -> None:
        for dock in self._docks:
            if dock.is_free:
                dock._park(bike)
                return
        raise StationFullError(f"Station {self._name} is full.")

    def take_bike(self) -> Bike:
        for dock in self._docks:
            if dock.bike is not None and dock.bike.status is BikeStatus.AVAILABLE:
                return dock._remove()
        raise NoBikeError(f"No available bike at {self._name}.")

    def __str__(self) -> str:
        return f"{self._name}: {len(self)}/{len(self._docks)} bikes"

    def __repr__(self) -> str:
        return f"Station(name={self._name!r}, docks={len(self._docks)})"

    def __lt__(self, other: "Station") -> bool:
        if not isinstance(other, Station):
            return NotImplemented
        return self.free_docks < other.free_docks


@dataclass
class Ride:
    bike: Bike
    start_station: Station
    start_time: datetime
    end_station: Station | None = None
    end_time: datetime | None = None
    failed_returns: int = 0

    FREE_MINUTES = 15
    BILLING_BLOCK_MINUTES = 5
    PRICE_PER_BLOCK = 500
    MAX_FEE = 20_000
    MAX_FAILED_RETURNS = 2

    def finish(self, end_station: Station, end_time: datetime) -> int:
        if end_time < self.start_time:
            raise ValueError("End time cannot be earlier than start time.")
        self.end_station = end_station
        self.end_time = end_time
        return self.fee

    @property
    def fee(self) -> int:
        if self.end_time is None:
            raise ValueError("An unfinished ride has no final fee.")
        seconds = (self.end_time - self.start_time).total_seconds()
        billable_seconds = max(0, seconds - self.FREE_MINUTES * 60)
        if billable_seconds == 0:
            return 0
        block_seconds = self.BILLING_BLOCK_MINUTES * 60
        blocks = (int(billable_seconds) + block_seconds - 1) // block_seconds
        return min(blocks * self.PRICE_PER_BLOCK, self.MAX_FEE)

    @property
    def duration_minutes(self) -> int:
        if self.end_time is None:
            raise ValueError("Ride is not finished.")
        seconds = int((self.end_time - self.start_time).total_seconds())
        return (seconds + 59) // 60


@dataclass
class User:
    user_id: str
    active_ride: Ride | None = None


class ReceiptPrinter:
    @staticmethod
    def print(ride: Ride) -> str:
        if ride.end_station is None or ride.end_time is None:
            raise ValueError("Cannot print a receipt for an unfinished ride.")
        return (
            f"{ride.start_station.name} → {ride.end_station.name}, "
            f"{ride.duration_minutes} min, {ride.fee:,} sum"
        )


class Network:
    def __init__(self, stations: Iterable[Station]):
        self._stations = tuple(stations)
        if not self._stations:
            raise ValueError("Network must contain at least one station.")
        if len({station.name for station in self._stations}) != len(self._stations):
            raise ValueError("Station names must be unique.")

    @property
    def stations(self) -> tuple[Station, ...]:
        return self._stations

    def take_bike(self, user: User, station: Station, at: datetime) -> Ride:
        if user.active_ride is not None:
            raise RideActiveError("User already has an active ride.")
        if station not in self._stations:
            raise ValueError("Station does not belong to this network.")
        bike = station.take_bike()
        ride = Ride(bike=bike, start_station=station, start_time=at)
        user.active_ride = ride
        return ride

    def return_bike(self, user: User, station: Station, at: datetime) -> tuple[Ride, str]:
        ride = user.active_ride
        if ride is None:
            raise NoActiveRideError("User has no active ride.")
        if station not in self._stations:
            raise ValueError("Station does not belong to this network.")
        if at < ride.start_time:
            raise ValueError("Return time cannot be earlier than start time.")

        if station.free_docks == 0:
            ride.failed_returns += 1
            redirect = None
            if ride.failed_returns >= Ride.MAX_FAILED_RETURNS:
                candidates = [s for s in self._stations if s.free_docks > 0]
                if candidates:
                    redirect = sorted(candidates, key=lambda s: (-s.free_docks, s.name))[0]
            raise StationFullError(
                f"Station {station.name} is full; ride is still active.",
                attempts=ride.failed_returns,
                redirect_station=redirect,
            )

        station.park_bike(ride.bike)
        ride.finish(station, at)
        user.active_ride = None
        return ride, ReceiptPrinter.print(ride)

    def report(self) -> str:
        ordered = sorted(self._stations, key=lambda s: (-s.free_docks, s.name))
        return "\n".join(f"{s.name}: {s.free_docks} free docks" for s in ordered)
