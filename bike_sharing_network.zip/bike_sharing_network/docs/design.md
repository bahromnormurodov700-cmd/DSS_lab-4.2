# Design discovery — Bike Sharing Network

## Noun sorting

| Noun / phrase | Decision | Reason |
|---|---|---|
| Tashkent bike network | Class: Network | Coordinates stations and ride operations. |
| station | Class: Station | Owns a fixed collection of docks and station rules. |
| dock | Class: Dock | Holds zero or one bike and protects occupancy. |
| bike | Class: Bike | Has identity, status and repair behaviour. |
| rider / user | Class: User | Has identity and at most one active ride. |
| ride | Class: Ride | Event with start/end data; owns duration and fee calculation. |
| manager | Actor | Person who reads station availability. |
| app / console | Actor / interface | Outside the domain model. |
| fixed number | Attribute / constructor value | A station's dock count. |
| first 15 minutes | Constant | Part of the Ride fee policy. |
| 500 sum | Constant | Price per started billing block. |
| 5 minutes | Constant | Billing block size. |
| 20,000 sum | Constant | Maximum fee. |
| start/end station | Ride attributes | Two roles played by Station. |
| start/end time | Ride attributes | Datetime values describing the event. |
| receipt | Output value | Formatted representation of a completed Ride. |
| free dock count | Derived attribute | Calculated from Station's docks. |
| repair | Bike state / behaviour | A bike remains docked but is not rentable. |
| return failure | Ride state | Failed-return counter belongs to the active Ride. |
| redirect station | Exception data | Suggested recovery location after two failures. |

## CRC cards

| Class | Responsibilities | Collaborators |
|---|---|---|
| Bike | Protect bike identity/status; enter and leave repair; know its dock | Dock, Ride |
| Dock | Hold at most one bike; park/remove bike; reject occupied dock | Bike, Station |
| Station | Own fixed docks; park/take eligible bikes; count free docks; provide station display | Dock, Bike, Network |
| Ride | Record bike, stations and times; count failed returns; validate finish time; calculate capped fee | Bike, Station, Network |
| User | Keep user identity and at most one active ride | Ride, Network |
| Network | Start and return rides; enforce user/ride rules; select redirect station; report availability | Station, User, Ride, ReceiptPrinter |

## Information Expert decisions

- `Ride` owns all fee constants and the fee formula because it owns the start/end timestamps.
- `Station` knows whether it has free docks and which docked bikes are available.
- `Dock` owns the one-bike occupancy invariant.
- `Ride` owns its failed-return counter because the failures belong to that ride.
- `Network` chooses the redirect because it can inspect every station in the network.

## Scenario: rider returns a bike to a full station

1. `User` supplies the active `Ride` to `Network`.
2. `Network` asks the target `Station` whether it has a free dock.
3. `Station` reports zero free docks.
4. `Network` increments the active `Ride`'s failed-return counter.
5. On the second failure, `Network` selects the station with the most free docks; ties are alphabetical.
6. `Network` raises `StationFullError` carrying the redirect. The ride remains active and its clock is not stopped.
7. The rider retries at the redirect station. `Network` asks `Station` to park the bike.
8. `Station` asks a free `Dock` to park the bike. `Dock` updates the bike's dock and status.
9. `Ride` records the end station/time and calculates the fee.
10. `User`'s active ride is cleared and `ReceiptPrinter` formats the receipt.

All steps have an owning class; no responsibility is left unassigned.
