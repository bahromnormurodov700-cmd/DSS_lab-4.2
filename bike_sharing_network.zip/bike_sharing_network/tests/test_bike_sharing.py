from datetime import datetime, timedelta

import pytest

from bike_sharing import (
    Bike, BikeStatus, Dock, Network, Station, User, Ride,
    DockOccupiedError, RideActiveError, NoBikeError,
    NoActiveRideError, StationFullError, ReceiptPrinter,
)


T0 = datetime(2026, 1, 1, 10, 0)


def test_dock_rejects_a_second_bike_and_preserves_first():
    dock = Dock("D1")
    first, second = Bike("B1"), Bike("B2")
    dock._park(first)
    with pytest.raises(DockOccupiedError):
        dock._park(second)
    assert dock.bike is first
    assert second.status is BikeStatus.IN_USE


def test_station_exposes_read_only_dock_collection_and_separate_instances():
    one, two = Station("One", 2), Station("Two", 2)
    assert isinstance(one.docks, tuple)
    assert one.docks is not two.docks
    with pytest.raises(AttributeError):
        one.docks = ()


def test_station_length_counts_parked_bikes_and_string_is_readable():
    station = Station("Chilonzor", 3)
    station.park_bike(Bike("B1"))
    assert len(station) == 1
    assert str(station) == "Chilonzor: 1/3 bikes"


def test_repair_bike_stays_docked_but_cannot_be_taken():
    station = Station("A", 1)
    bike = Bike("B1")
    station.park_bike(bike)
    bike.send_to_repair()
    assert bike.dock is station.docks[0]
    with pytest.raises(NoBikeError):
        station.take_bike()
    bike.finish_repair()
    assert station.take_bike() is bike


def test_two_station_objects_have_independent_docks():
    first, second = Station("A", 1), Station("B", 1)
    first.park_bike(Bike("B1"))
    assert len(first) == 1
    assert len(second) == 0


def test_exactly_fifteen_minutes_costs_zero_and_fifteen_minutes_one_second_costs_500():
    station_a, station_b = Station("A", 2), Station("B", 2)
    ride = Ride(Bike("B1"), station_a, T0)
    ride.finish(station_b, T0 + timedelta(minutes=15))
    assert ride.fee == 0
    ride.end_time = T0 + timedelta(minutes=15, seconds=1)
    assert ride.fee == 500


def test_started_five_minute_blocks_are_rounded_up():
    ride = Ride(Bike("B1"), Station("A", 1), T0)
    ride.finish(Station("B", 1), T0 + timedelta(minutes=20))
    assert ride.fee == 500
    ride.end_time = T0 + timedelta(minutes=20, seconds=1)
    assert ride.fee == 1000


def test_fee_is_capped_at_twenty_thousand():
    ride = Ride(Bike("B1"), Station("A", 1), T0)
    ride.finish(Station("B", 1), T0 + timedelta(days=2))
    assert ride.fee == 20_000


def test_end_time_before_start_time_is_rejected():
    ride = Ride(Bike("B1"), Station("A", 1), T0)
    with pytest.raises(ValueError):
        ride.finish(Station("B", 1), T0 - timedelta(seconds=1))


def test_receipt_printer_formats_completed_ride():
    ride = Ride(Bike("B1"), Station("Chilonzor", 1), T0)
    ride.finish(Station("Yunusobod", 1), T0 + timedelta(minutes=23))
    assert ReceiptPrinter.print(ride) == "Chilonzor → Yunusobod, 23 min, 1,000 sum"


def test_user_can_have_only_one_active_ride():
    station = Station("A", 2)
    station.park_bike(Bike("B1"))
    station.park_bike(Bike("B2"))
    network, user = Network([station]), User("U1")
    network.take_bike(user, station, T0)
    with pytest.raises(RideActiveError):
        network.take_bike(user, station, T0 + timedelta(minutes=1))


def test_no_active_ride_cannot_be_returned():
    station = Station("A", 1)
    with pytest.raises(NoActiveRideError):
        Network([station]).return_bike(User("U1"), station, T0)


def test_return_to_full_station_keeps_ride_active_then_redirects_after_two_failures():
    start_station = Station("Start", 2)
    full_station = Station("Full", 1)
    best = Station("Best", 3)
    start_station.park_bike(Bike("B1"))
    full_station.park_bike(Bike("B2"))
    network, user = Network([start_station, full_station, best]), User("U1")
    network.take_bike(user, start_station, T0)

    with pytest.raises(StationFullError) as first:
        network.return_bike(user, full_station, T0 + timedelta(minutes=10))
    assert first.value.attempts == 1
    assert first.value.redirect_station is None
    assert user.active_ride is not None

    with pytest.raises(StationFullError) as second:
        network.return_bike(user, full_station, T0 + timedelta(minutes=11))
    assert second.value.attempts == 2
    assert second.value.redirect_station is best
    assert user.active_ride is not None


def test_recovery_at_redirected_station_closes_ride_and_prints_receipt():
    start_station = Station("Start", 1)
    full_station = Station("Full", 1)
    redirect = Station("Redirect", 2)
    start_station.park_bike(Bike("B1"))
    full_station.park_bike(Bike("B2"))
    network, user = Network([start_station, full_station, redirect]), User("U1")
    network.take_bike(user, start_station, T0)
    for minute in (10, 11):
        with pytest.raises(StationFullError):
            network.return_bike(user, full_station, T0 + timedelta(minutes=minute))
    ride, receipt = network.return_bike(
        user, redirect, T0 + timedelta(minutes=12)
    )
    assert user.active_ride is None
    assert ride.end_station is redirect
    assert len(redirect) == 1
    assert receipt.startswith("Start → Redirect")


def test_no_available_bike_when_station_is_empty():
    station = Station("Empty", 2)
    with pytest.raises(NoBikeError):
        station.take_bike()


def test_manager_report_orders_by_free_docks_descending_then_name():
    a, b, c = Station("A", 3), Station("B", 2), Station("C", 1)
    a.park_bike(Bike("A1"))
    b.park_bike(Bike("B1"))
    report = Network([b, c, a]).report().splitlines()
    assert report == ["A: 2 free docks", "B: 1 free docks", "C: 1 free docks"]
