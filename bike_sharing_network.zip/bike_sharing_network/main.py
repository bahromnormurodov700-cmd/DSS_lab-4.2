from datetime import datetime, timedelta

from bike_sharing import Bike, Network, Station, User, StationFullError


def main():
    chilonzor = Station("Chilonzor", 2)
    yunusobod = Station("Yunusobod", 2)
    sergeli = Station("Sergeli", 1)

    chilonzor.park_bike(Bike("B-001"))
    chilonzor.park_bike(Bike("B-002"))
    yunusobod.park_bike(Bike("B-003"))

    network = Network([chilonzor, yunusobod, sergeli])
    rider = User("U-001")
    start = datetime(2026, 11, 10, 10, 0)

    print("HAPPY PATH")
    ride = network.take_bike(rider, chilonzor, start)
    finished, receipt = network.return_bike(rider, yunusobod, start + timedelta(minutes=23))
    print(receipt)

    print("\nFAILURE AND RECOVERY PATH")
    # Fill Sergeli, then attempt to return another bike there.
    sergeli.park_bike(Bike("B-004"))
    ride = network.take_bike(rider, yunusobod, start + timedelta(hours=1))
    redirect_station = None
    for attempt in range(1, 3):
        try:
            network.return_bike(rider, sergeli, start + timedelta(hours=1, minutes=10))
        except StationFullError as exc:
            print(f"Failed return {attempt}: {exc}")
            if exc.redirect_station:
                redirect_station = exc.redirect_station
                print(f"Redirect to: {redirect_station.name}")
    # Return to the station recommended by the second failed attempt.
    _, receipt = network.return_bike(
        rider, redirect_station, start + timedelta(hours=1, minutes=10)
    )
    print("Recovered:", receipt)

    print("\nMANAGER REPORT")
    print(network.report())


if __name__ == "__main__":
    main()
