# Bike Sharing Network

Console-only bike-sharing model for Python 3.10+. The implementation demonstrates classes, encapsulation, relationships, datetime billing, exceptions and recovery after a full-station return.

> Study note: the original lab brief says AI-generated submissions are not allowed. Treat this repository as a learning/reference implementation. Read it, run it, and make sure you can explain every design decision. Follow your instructor's current permission and submission rules.

## Requirements

- Python 3.10+
- pytest (tests only)

## Run

```bash
python main.py
```

Run tests:

```bash
python -m pip install pytest
pytest -v
```

## Domain rules implemented

- A station has a fixed number of docks; each dock holds at most one bike.
- Bikes parked in a dock are `AVAILABLE`, unless explicitly in `REPAIR`.
- A repair bike stays in its dock and cannot be rented.
- A user can have at most one active ride.
- A ride can be returned to any station with a free dock.
- First 15 minutes are free. Every started 5-minute block after that costs 500 sum.
- The fee is capped at 20,000 sum.
- A failed return to a full station leaves the ride active. On the second failed attempt, the exception carries a redirect station: most free docks, then name A–Z.
- Time is injected as a parameter; model classes never call `datetime.now()`.

## Demo video checklist (maximum 40 seconds)

Record your own screen and place the video here or embed it below. Suggested sequence:

1. Run `python main.py`.
2. Show the happy path: take a bike and return it to a free dock; receipt displays route, duration and fee.
3. Show the full-station return failing twice; the ride remains active and the second exception gives a redirect.
4. Return to the redirected station; show the recovery receipt.
5. Run `pytest -v` and show all tests passing.

<details>
<summary>Demo video</summary>

Add your own video link here. Keep it under 40 seconds and make sure it shows the required steps.

</details>

## Relationships table

| Connected pair | Relationship | Multiplicity | Code evidence |
|---|---|---|---|
| Station — Dock | Composition | Station 1 → Dock 1..*; Dock → Station 0..1 via Bike link only | `bike_sharing/models.py`, `Station.__init__` creates its own tuple of `Dock` objects. |
| Dock — Bike | Association | Dock 0..1 Bike; Bike 0..1 Dock | `Dock._park`, `Dock._remove`, `Bike.dock`. |
| Station — Bike | Dependency | Station uses Bike 0..* through its docks | `Station.park_bike` and `Station.take_bike`. |
| Ride — Bike | Association | Ride 1 Bike; Bike 0..1 active Ride by application flow | `Ride.bike`; `Network.take_bike`. |
| Ride — Station (start) | Association | Ride 1 start Station; Station 0..* Rides | `Ride.start_station`. |
| Ride — Station (end) | Association | Ride 0..1 end Station; Station 0..* Rides | `Ride.end_station`. |
| User — Ride | Association | User 0..1 active Ride; Ride 0..1 active User by application flow | `User.active_ride`; `Network.take_bike` and `Network.return_bike`. |
| Network — Station | Aggregation | Network 1..* Stations; Station can exist independently | `Network.__init__` receives existing stations and stores them as a tuple. |
| Network — User | Dependency | Network uses User 0..* | `Network.take_bike` and `Network.return_bike` parameters. |
| Network — Ride | Dependency | Network creates/uses rides | `Network.take_bike` creates `Ride`; `Network.return_bike` finishes it. |
| ReceiptPrinter — Ride | Dependency | One call uses one Ride | `ReceiptPrinter.print(ride)`. |

### Lifetime checks

- Composition, Station → Dock: deleting a Station makes its owned Dock objects unreachable with that Station; the Station constructs them internally.
- Aggregation, Network → Station: deleting a Network does not delete its Station objects; callers created and passed them in.

### Multiplicity enforcement

- Dock 0..1 Bike is enforced by `Dock._park` rejecting an occupied dock.
- Station 1..* Dock is enforced by rejecting `dock_count <= 0`.
- User 0..1 active Ride is enforced by `Network.take_bike` raising `RideActiveError`.
- Network 1..* Station is enforced by rejecting an empty station collection.
- Ride 1 Bike and Ride 1 start Station are enforced by required constructor arguments.
- Ride end Station is optional until the ride is completed.

## Invariant: a bike is in exactly one place

A parked bike is referenced by exactly one `Dock` through `Bike._dock`; `Dock._park` rejects a bike whose `dock` is already set. Taking a bike removes it from the dock and clears `Bike._dock`; the active `Ride` then holds the bike reference while it is in transit. Returning parks it into one free dock before the ride is closed. Thus a bike is either in one dock or held by its active ride, never in two docks at once.

## Project layout

```text
bike_sharing_network/
├── bike_sharing/
│   ├── __init__.py
│   ├── exceptions.py
│   └── models.py
├── docs/
│   └── design.md
├── tests/
│   └── test_bike_sharing.py
├── main.py
├── README.md
└── requirements.txt
```
